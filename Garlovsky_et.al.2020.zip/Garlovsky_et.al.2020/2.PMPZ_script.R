library(tidyverse)
library(multcomp)
library(scales)

RdBu_pal <- c(RColorBrewer::brewer.pal(3, "RdBu"))

# load data
rad_dat <- read.csv("MDG_Dmon_CSP_data/2.PMPZ_data.csv") %>% 
  filter(eggs > 10) # all analyses were performed after removing females that laid less than 10 eggs

str(rad_dat)
# $ BLOCK     : experimental block
# $ cross_1   : first mating female population x male population
# $ cross_type: second mating female population x male 1 population x male 2 population
# $ female    : female population (Colorado or Vancouver)
# $ Mating    : first or second mating
# $ RADS      : irradiation treatment; first male (M1), second male (M2), both males (DOUBLE), or neither (CONTROL)
# $ eggs      : number of eggs laid
# $ hatch     : number of eggs laid that hatched
# $ unhatched : eggs - hatch

# reorder cross_type to have within-population comparison as reference
rad_dat$cross_type <- factor(rad_dat$cross_type, 
                             levels = c("CCC", "CCV", "CVC", "CVV", 
                                        "VVV", "VVC", "VCV", "VCC"))

# facet labels for plotting
facet_names <- c(C = "Colorado", V = "Vancouver")


# Postmating prezygotic isolation of virgin females: non-competitive gametic isolation (NCGI) ####
# Figure S4
rad_dat %>% 
  filter(RADS == 'CONTROL', Mating == '1') %>% 
  mutate(h = hatch/eggs * 100) %>% 
  ggplot(aes(x = cross_1, y = h)) +
  geom_boxplot(outlier.shape = NA) +
  geom_jitter(aes(size = eggs, fill = cross_1), pch = 21, width = .3, alpha = .8) +
  labs(y = "Hatching success (%)") +
  scale_fill_brewer(palette = "RdBu") +
  theme_bw() +
  theme(legend.position = c(0.05, 0.15),
        legend.title = element_blank(),
        legend.background = element_blank(),
        axis.title.x = element_blank(),
        strip.text = element_text(face = "bold", size = 15),
        strip.background = element_rect(fill = "grey"),
        plot.background = element_rect(colour = NA)) +
  guides(fill = FALSE) +
  facet_wrap(~ female, scales = "free_x", labeller = as_labeller(facet_names)) +
  geom_text(data = rad_dat %>% 
              filter(RADS == 'CONTROL' & Mating == '1' & eggs > 0) %>% 
              group_by(cross_1) %>% 
              summarise(N = n()) %>% 
              mutate(h = -5,
                     female = c("C", "C", "V", "V")), 
            aes(label = paste0("n = ", N)), size = 3) +
  NULL


# means and standard errors
rad_dat %>% 
  filter(RADS == 'CONTROL' & Mating == '1') %>% 
  dplyr::select(cross_type, hatch, eggs) %>% na.omit() %>% 
  mutate(p = hatch/eggs,
         cross = factor(substr(cross_type, 1, 2))) %>% 
  group_by(cross) %>% 
  summarise(mn = mean(p),
            sd_p = sd(p),
            se = sd(p)/sqrt(n()),
            N = n())



# subset data by population 

# Colorado
c_hatch1 <- subset(rad_dat, female == 'C') %>% 
  filter(RADS == 'CONTROL' & Mating == '1') %>% # filter first mating in nonirradiated crosses only

  mutate(unhatched = eggs - hatch)

col_h1 <- glm(cbind(hatch, unhatched) ~ cross_1, data = c_hatch1, family = "binomial")
summary(col_h1) # model is showing overdispersion - use quasi-binomial errors

col_h1 <- glm(cbind(hatch, unhatched) ~ cross_1, data = c_hatch1, family = "quasibinomial")
anova(col_h1, test = "F")
summary(col_h1)


# Vancouver
v_hatch1 <- subset(rad_dat, female == 'V') %>% 
  filter(RADS == 'CONTROL' & Mating == '1') %>% 
  mutate(unhatched = eggs - hatch, 
         cross_1 = relevel(cross_1, ref = 'VV'),
         cross_type = relevel(cross_type, ref = "VVV"))


van_h1 <- glm(cbind(hatch, unhatched) ~ cross_1, data = v_hatch1, family = "binomial")
summary(van_h1) # again, overdispersion

van_h1 <- glm(cbind(hatch, unhatched) ~ cross_1, data = v_hatch1, family = "quasibinomial")
anova(van_h1, test = "F")
summary(van_h1)



# Postmating prezygotic isolation of non-virgin females (hatching success) --------------------------------------------------------

# means and standard errors
rad_dat %>% 
  dplyr::select(cross_type, hatch, eggs, RADS, Mating) %>% 
  filter(RADS == 'CONTROL' & Mating == '2') %>% 
  group_by(cross_type) %>% 
  summarise(mn = mean(hatch/eggs),
            se = sd(hatch/eggs)/sqrt(n()),
            N = n())


# Colorado hatch rates
col_dat <- rad_dat %>% 
  filter(female == 'C' & RADS == 'CONTROL' & Mating == '2')

col_mod <- glm(cbind(hatch, unhatched) ~ cross_type, data = col_dat, family = "binomial")
summary(col_mod) # again, overdispersion

col_mod <- glm(cbind(hatch, unhatched) ~ cross_type, data = col_dat, family = "quasibinomial")
anova(col_mod, test = "F")
summary(col_mod)

# Tukey's HSD
tukey.col <- glht(col_mod, linfct = mcp(cross_type = "Tukey"))
summary(tukey.col)



# Vancouver
van_dat <- rad_dat %>% 
  filter(female == 'V' & RADS == 'CONTROL' & Mating == '2')

#Vancouver hatch rates
van_mod <- glm(cbind(hatch, unhatched) ~ cross_type, data = van_dat, family = "binomial")
summary(van_mod) # again, overdispersion

van_mod <- glm(cbind(hatch, unhatched) ~ cross_type, data = van_dat, family = "quasibinomial")
anova(van_mod, test = "F")
summary(van_mod)

tukey.van <- glht(van_mod, linfct = mcp(cross_type = "Tukey"))
summary(tukey.van)


# Combine letters from Tukey's HSD for plotting
hatch.letters <- data.frame(cross_type = levels(rad_dat$cross_type),
                            pos = 1.05,
                            labs = c(cld(summary(glht(col_mod, linfct = mcp(cross_type = "Tukey"))), 
                                         decreasing = T)$mcletters$Letters, 
                                     cld(summary(glht(van_mod, linfct = mcp(cross_type = "Tukey"))), 
                                         decreasing = T)$mcletters$Letters),
                            female = rep(c("C", "V"), each = 4))

# summarise hatching success data for plotting
hatch.data <- rad_dat %>% 
  filter(RADS == 'CONTROL' & Mating == '2') %>% 
  dplyr::select(cross_type, hatch, eggs) %>% na.omit() %>% 
  mutate(h = hatch/eggs) %>% 
  group_by(cross_type) %>% 
  summarise(mn_h = mean(h),
            se_h = sd(h)/sqrt(n()),
            N = n())

# Figure S5
ggplot(rad_dat %>% 
         filter(RADS == 'CONTROL' & Mating == '2') %>% 
         mutate(h = hatch/eggs), 
       aes(x = cross_type, y = h * 100)) +
  geom_boxplot(outlier.shape = NA) +
  geom_jitter(aes(size = eggs, fill = female), pch = 21, width = .3, alpha = .8) +
  scale_fill_manual(values = RdBu_pal[c(1,3)]) +
  guides(fill = FALSE) +
  labs(y = "Hatching success (%)") +
  theme_bw() +
  theme(legend.position = c(0.05, 0.15),
        legend.title = element_blank(),
        legend.background = element_blank(),
        axis.title.x = element_blank(),
        axis.text.x = element_text(face = "bold", size = 10),
        strip.text = element_text(face = "bold", size = 15),
        strip.background = element_rect(fill = "grey"),
        plot.background = element_rect(colour = NA)) +
  geom_text(data = hatch.letters, aes(y = pos * 100, label = labs), 
            size = 5, colour = "black") +
  facet_wrap(~ female, scales = "free_x", labeller = as_labeller(facet_names))



# CALCULATE P2 ------------------------------------------------------------

# level of fertility from mating with two irradiated males (all are 100% sterile)
rad_dat %>% 
  filter(RADS == 'DOUBLE' & Mating == 2) %>% 
  group_by(cross_type) %>% 
  summarise(z = mean(hatch/eggs))

# level of fertility from mating with two nonirradiated males in each cross-type
p_dat <- rad_dat %>%
  filter(RADS == 'CONTROL' & Mating == 2) %>% 
  group_by(cross_type) %>% 
  summarise(p = mean(hatch/eggs), # average fertility in each cross-type
            p_max = max(hatch/eggs), # maximum fertility in each cross-type
            p_var = var(hatch/eggs),
            p_se = sd(hatch/eggs)/sqrt(n())) 


rads_2 <- rad_dat %>% 
  filter(Mating == 2 & !RADS %in% c("DOUBLE", "CONTROL")) %>% 
  mutate(x = hatch/eggs,
         
         p = unlist(cross_type %>% map(~ p_dat$p_max[p_dat$cross_type == .x])), 
         
         z = 0,
         
         # Equation (1) from Boorman and Parker (1976)
         # x = p(observed developed eggs)
         # p = p(developed eggs from CONTROL (female x fertile x fertile) mating)
         # z = p(developed eggs from DOUBLE (female x rads x rads) mating)
         
         P_r = 
           
           (1 - x/p) + (z/p * 
                          (1 - (x/p))
                        /
                          (1 - (z/p))
           ), # cancels to (1 - x/p) because z = 0
         
         # if first male rads P2 = 1 - P_r, if second male rads P2 = P_r
         P2 = if_else(RADS == "M1", 1 - P_r, P_r) 
         
  ) %>% # multiply P2 values by number of eggs laid to get number of offspring sired by second male
  mutate(P_2f = round(P2 * eggs), 
         # assign remainder of eggs to first male - accounting for expected proportion hatching (p)
         P_1f = round(p * (eggs - P_2f)))


# reorder crosses
rads_2$cross_type <- factor(rads_2$cross_type, levels = c("CCC", "CCV", "CVC", "CVV", 
                                                          "VVV", "VVC", "VCV", "VCC"))

# average P2 for each cross
rads_2 %>% 
  group_by(cross_type) %>% 
  summarise(mn = mean(P2),
            std.error = sd(P2)/sqrt(n()),
            N = n())



# Summarise PMPZ after second mating ---------------------------------------------------
# get means and standard errors
plot.data <- left_join(hatch.data %>% 
  mutate(female = factor(substr(cross_type, 1, 1))),
  rads_2 %>% 
    group_by(cross_type) %>% 
    summarise(mn_P = mean(P2),
              se_P = sd(P2)/sqrt(n())), 
  by = 'cross_type') %>% 
  mutate(h2 = mn_h * mn_P,
         h1 = mn_h - h2,
         males = stringi::stri_reverse(substr(cross_type, 2, 3)),
         m2_m1 = vapply(strsplit(males, ""), function(x) paste(x, collapse="\n\n"), character(1L)))

plot.data$m2_m1 <- gsub("C", "Col", plot.data$m2_m1)
plot.data$m2_m1 <- gsub("V", "Van", plot.data$m2_m1)
plot.data$lab2 <- paste0(plot.data$m2_m1, "\n\n", 
                         round(plot.data$mn_P, 2), "±", 
                         round(plot.data$se_P, 2))

# change order of crosses
plot.data$lab2 <- factor(plot.data$lab2, levels = c("Col\n\nCol\n\n0.7±0.05",
                                                    "Van\n\nCol\n\n0.21±0.06",
                                                    "Col\n\nVan\n\n0.84±0.04",
                                                    "Van\n\nVan\n\n0.49±0.09",
                                                    "Van\n\nVan\n\n0.63±0.05", 
                                                    "Col\n\nVan\n\n0.48±0.05", 
                                                    "Van\n\nCol\n\n0.71±0.05",     
                                                    "Col\n\nCol\n\n0.6±0.04"))

# Figure 3
plot.data %>% 
  ggplot(aes(x = lab2, y = mn_h, fill = female)) +
  geom_bar(stat = 'identity') +
  geom_errorbar(aes(ymin = mn_h - se_h, ymax = mn_h + se_h), width = .2) +
  geom_bar(aes(y = h1), stat = 'identity', fill = 'grey') +
  geom_errorbar(aes(ymin = h1 - se_P, ymax = h1 + se_P), width = .2) +
  scale_y_continuous(limits = c(0, 1), labels = percent) +
  scale_fill_manual(values = RdBu_pal[c(1,3)]) +
  labs(y = 'Hatching success (%)') +
  theme_bw() +
  theme(legend.position = "none",
        axis.title.x = element_blank(),
        axis.text.x = element_text(face = "bold", size = 10),
        strip.text = element_text(face = "bold", size = 15),
        strip.background = element_rect(fill = "grey"),
        plot.background = element_rect(colour = NA)) +
  facet_wrap(~ female, scales = "free_x", labeller = as_labeller(facet_names)) +
  NULL



# P2 ANALYSIS -------------------------------------------------------------

# COLORADO
Col_dat <- subset(rads_2, female == 'C')

# means and standard errors
Col_dat %>% 
  group_by(cross_type) %>% 
  summarise(av.p2 = mean(P2),
            se.p2 = sd(P2)/sqrt(n()),
            N = n())


# prelim analysis - including CVV cross-type
m1 <- glm(cbind(P_2f, P_1f) ~ cross_type * RADS, data = Col_dat, family = "binomial")
summary(m1) # overdispersion

m1.q <- glm(cbind(P_2f, P_1f) ~ cross_type * RADS, data = Col_dat, family = "quasibinomial")
anova(m1.q, test = "F")

drop1(m1.q, test = "F")

summary(m1.q)

summary(glht(m1.q, linfct = mcp(cross_type = 'Tukey')))



# drop CVV cross-type
Col_d2 <- Col_dat %>% filter(cross_type != 'CVV')

m1 <- glm(cbind(P_2f, P_1f) ~ cross_type * RADS, data = Col_d2, family = "binomial")
summary(m1) # overdispersion

m1.q <- glm(cbind(P_2f, P_1f) ~ cross_type * RADS, data = Col_d2, family = "quasibinomial")
anova(m1.q, test = "F")

drop1(m1.q, test = "F")

summary(m1.q)


summary(glht(m1.q, linfct = mcp(cross_type = 'Tukey')))


# VANCOUVER
Van_dat <- subset(rads_2, female == 'V')

Van_dat %>% 
  group_by(cross_type) %>% 
  summarise(av.p2 = mean(P2),
            se.p2 = sd(P2)/sqrt(n()),
            N = n())


m2 <- glm(cbind(P_2f, P_1f) ~ cross_type * RADS, data = Van_dat, family = "binomial")
anova(m2, test = "Chisq")
summary(m2) # overdispersion

m2.q <- glm(cbind(P_2f, P_1f) ~ cross_type * RADS, data = Van_dat, family = "quasibinomial")
anova(m2.q, test = "F")

drop1(m2.q, test = "F")

summary(m2.q)

summary(glht(m2.q, linfct = mcp(cross_type = "Tukey")))


# 
csp.letters <- data.frame(cross_type = levels(rad_dat$cross_type),
                          pos = 1.05,
                          labs = c(cld(summary(glht(m1.q, linfct = mcp(cross_type = "Tukey"))), 
                                       decreasing = T)$mcletters$Letters, 
                                   "NA", # CVV cross
                                   cld(summary(glht(m2.q, linfct = mcp(cross_type = "Tukey"))), 
                                       decreasing = T)$mcletters$Letters),
                          female = c(rep("C", 4), rep("V", 4)))


# Figure SX showing irradiation order effects on p2 
ggplot(rads_2, 
       aes(x = cross_type, y = P2)) +
  geom_boxplot(outlier.shape = NA) +
  geom_jitter(aes(size = eggs, fill = RADS), pch = 21, width = .3, alpha = .8) +
  scale_fill_viridis_d() +
  labs(y = expression(P[2])) +
  guides(fill = guide_legend(override.aes = list(size = 5))) +
  theme_bw() +
  theme(legend.position = 'top',
        legend.title = element_blank(),
        legend.background = element_blank(),
        axis.title.x = element_blank(),
        axis.text.x = element_text(face = "bold", size = 10),
        strip.text = element_text(face = "bold", size = 15),
        strip.background = element_rect(fill = "grey"),
        plot.background = element_rect(colour = NA)) +
  geom_text(data = csp.letters, aes(y = pos, label = labs), 
            size = 5, colour = "black") +
  facet_wrap(~ female, scales = "free_x", labeller = as_labeller(facet_names))



# Interaction between coevolved and foreign male ejaculates in the FRT -----
# Given we know proportion of offspring sired by each male in cross-type (P2) and expected
# Hatching success in a single mating, if each male contributes indepedently to overall fertilisation
# success we should be able to work back to observed hatching success for a given double mating
# for each cross-type using the equation:

# H_total = (P2 * H2) + ((1 - P2) * H1)

# H1 = Hatching success for female x male 1
# H2 = Hatching success for female x male 2

# mean hatcing success for a single mating
HR2 <- rad_dat %>% 
  filter(RADS == 'CONTROL' & Mating == '1') %>% 
  group_by(cross_1) %>% 
  summarise(H = mean(hatch/eggs),
            H.se = sd(hatch/eggs)/sqrt(n()))

# Table SX
calc_h <- rads_2 %>% 
  filter(Mating == 2) %>% 
  group_by(cross_type) %>% 
  summarise(N = n(),
            mn_p2 = mean(P2)) %>% 
  mutate(H_obs = hatch.data$mn_h,
         H1 = c(rep(unlist(HR2[1:2, 2]), each = 2), # single mating hatch rates
                rep(unlist(HR2[4:3, 2]), each = 2)),
         H2 = c(rep(unlist(HR2[1:2, 2]), 2), # single mating hatch rates
                rep(unlist(HR2[4:3, 2]), 2)),
         H_m1 = (1 - mn_p2) * H1,
         H_m2 = mn_p2 * H2,
         H_tl = H_m1 + H_m2,
         delta = H_obs - H_tl) # difference between estimated and observed

# Figure SX
rad_dat %>%
  filter(RADS == 'CONTROL' & Mating == 2 & eggs > 0) %>% 
  mutate(H = (hatch/eggs)*100) %>% 
  group_by(cross_type) %>% 
  ggplot(aes(x = cross_type, y = H)) +
  geom_violin() +
  geom_boxplot(width = .1, aes(fill = female), fatten = NULL) +
  scale_fill_manual(values = RdBu_pal[c(1,3)]) +
  facet_wrap(~ female, scales = 'free_x', labeller = as_labeller(facet_names)) +
  labs(y = "Hatching success (%)") +
  guides(colour = FALSE) +
  theme_bw() + 
  theme(legend.position = 'none',
        axis.title.x = element_blank(),
        strip.text = element_text(face = "bold", size = 25),
        strip.background = element_rect(fill = "grey"),
        plot.background = element_rect(colour = NA)) +
  stat_summary(fun.y = mean, fun.ymin = mean, fun.ymax = mean,
               geom = "point", pch = 21, size = 3, stroke = 1.2, colour = "black", fill = "white") + 
  geom_point(data = calc_h %>% 
               rename(H = H_tl) %>% 
               mutate(H = H * 100, 
                      female = rep(c("C", "V"), each = 4)),
             size = 3, fill = 'red', shape = 23)


