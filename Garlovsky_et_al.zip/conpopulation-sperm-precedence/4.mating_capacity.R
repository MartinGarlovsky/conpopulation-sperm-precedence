library(tidyverse)
library(multcomp)
library(lme4)
library(glmmTMB)
library(DHARMa)

RdBu_pal <- c(RColorBrewer::brewer.pal(3, "RdBu"))

cap_dat <- read.csv("MDG_Dmon_CSP_data/4.mating_capacity.csv") 

str(cap_dat)
# $ Male_ID: Unique male ID
# $ Mating : Mating number
# $ POP    : Population (Colorado or Vancouver)
# $ count  : Progeny count


cap_dat %>% 
  group_by(POP) %>% 
  summarise(n_distinct(Male_ID))

# Mean total progeny produced
cap_dat %>% 
  group_by(POP) %>% 
  summarise(total = sum(count),
            mn = total/mean(Mating),
            N = n()) 

# summarise total offspring and number of matings per male
sum_dat <- cap_dat %>% 
  group_by(Male_ID, POP) %>% 
  summarise(m = max(Mating),
            w = sum(count))


# number of matings
boxplot(m ~ POP, sum_dat)
mate_mod <- glm(m ~ POP, data = sum_dat, family = 'poisson')
anova(mate_mod, test = 'Chisq')
summary(mate_mod)

# total offspring
boxplot(w ~ POP, sum_dat)
prog_mod <- glm(w ~ POP, data = sum_dat, family = 'poisson')
anova(prog_mod, test = 'Chisq')
summary(prog_mod) # overdispersed

prog_mod <- glm(w ~ POP, data = sum_dat, family = 'quasipoisson')
anova(prog_mod, test = 'F')
summary(prog_mod)


sum_dat %>% 
  group_by(POP) %>% 
  summarise(mn.offspring = mean(w),
            se.offspring = sd(w)/sqrt(n()),
            mn.mating = mean(m),
            se.mating = sd(m)/sqrt(n()),
            per.mating = mn.offspring/mn.mating,
            N = n())



# Per mating progeny production
ggplot(cap_dat, aes(x = Mating, y = count, colour = POP)) +
  geom_point() +
  geom_smooth(method = 'lm', se = FALSE) +
  scale_x_continuous(breaks = 1:10) +
  theme_bw() +
  theme(legend.position = c(0.8, .9),
        legend.title = element_blank(),
        legend.text = element_text(size = 15))


hist(cap_dat$count)

# mixed effect model to look at male per mating investment
mod1 <- glmer(count ~ POP * Mating + (1|Male_ID), data = cap_dat, family = 'poisson')
anova(mod1)
summary(mod1)

# model diagnostics
mod1_diagnostics <- fortify(mod1)

mod11 <- ggplot(mod1_diagnostics, aes(x = .fitted, y = .resid)) + geom_point() +
  geom_hline(yintercept = 0, lty = 'dashed')
mod12 <- ggplot(mod1_diagnostics, aes(sample = .scresid)) + 
  stat_qq() + 
  geom_abline()
mod13 <- ggplot(mod1_diagnostics, aes(x = .fitted, y = .resid)) + 
  geom_point() +
  geom_hline(yintercept = 0, lty = 'dashed') + 
  facet_wrap(~ Male_ID)

# don't look good
gridExtra::grid.arrange(mod11, mod12, mod13, ncol = 2)

# model ignoring male pseudoreplication
mod.diag <- glm(count ~ POP * Mating, data = cap_dat, family = 'poisson')
anova(mod.diag, test = 'Chisq')
summary(mod.diag) # model is overdispersed

# use zero-inflated poisson model from 'glmmTMB package
mod1 <- glmmTMB(count ~ POP * Mating + (1|Male_ID), data = cap_dat, ziformula = ~1, family = 'poisson')
car::Anova(mod1)
summary(mod1)

# model diagnostics look better
res.fit <- simulateResiduals(mod1)
plot(res.fit, rank = T)

# plot data and model fit
newX <- expand.grid(Mating = seq(from = 1, to = 10, by = 1),
                    POP = levels(cap_dat$POP),
                    Male_ID = unique(cap_dat$Male_ID))

newY <- predict(mod1, newdata = newX, type = "response", se.fit = T) 

adds <- data.frame(newX, newY)

# CI = fit ± 1.96*SE
adds <- mutate(adds, upr = fit + 1.96*se.fit, lwr = fit - 1.96*se.fit)

adds <- rename(adds, count = fit)

plot_data <- data.frame(newX, newY)
summary(plot_data)
head(plot_data)
colnames(plot_data)[4] <- "count"


plot_data_summary <- plot_data %>% 
  group_by(Mating, POP) %>% 
  summarise(mn_fit = mean(count),
            se_fit = mean(se.fit),
            ci_fit = qnorm(0.975) * se_fit) %>% 
  mutate(lwr = mn_fit - ci_fit,
         upr = mn_fit + ci_fit)


# Figure 4b
ggplot(cap_dat, aes(x = Mating, y = count, fill = POP)) +
  geom_line(data = plot_data_summary, 
            aes(y = mn_fit, colour = POP)) +
  geom_ribbon(data = plot_data_summary, 
              aes(y = mn_fit, ymin = lwr, ymax = upr, fill = POP, colour = POP), 
              stat = 'identity', lty = 0,
              alpha = .5) +
  geom_point(size = 3, pch = 21) +
  scale_fill_manual(values = RdBu_pal[-2]) +
  scale_colour_manual(values = RdBu_pal[c(1,3)]) +
  scale_x_continuous(breaks = c(2, 4, 6, 8, 10)) +
  theme_bw() +
  theme(legend.position = 'none',
        legend.title = element_blank(),
        legend.text = element_text(size = 25),
        legend.key.width = unit(2, "line"),
        plot.background = element_rect(colour = NA)) +
  annotate("text", x = 10, y = 95, size = 7, hjust = 1,
           label = paste0('Slope = ',
                          round(fixef(mod1)$cond[3], 2),
                          '\np < 0.001')) +
  NULL
