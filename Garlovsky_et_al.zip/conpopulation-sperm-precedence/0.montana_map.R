library(tidyverse)

RdBu_pal <- c(RColorBrewer::brewer.pal(3, "RdBu"))

# Locations of D. montana populations
collect_data <- data.frame(name = c("Vancouver", "Colorado", "Oulanka"),
                           loc = c("V", "C", "O"),
                           lon = c(-123.48, -107.04, 29.20),
                           lat = c(48.55, 38.49, 66.22),
                           ele = c(0, 0, 0))

# Load worldmap
world <- map_data("world")
worldmap <- ggplot(world, aes(x = long, y = lat, group = group)) +
  geom_path() +
  scale_y_continuous(breaks = (-2:2) * 30) +
  scale_x_continuous(breaks = (-4:4) * 45) +
  geom_polygon(aes(x = long, y = lat, group = group), 
               colour = "grey", fill = "grey")

# Draw map in globe view looking down at North Pole.
worldmap + 
  coord_map("ortho", orientation = c(50, -50, -30)) +
  annotate("point", x = -107.04, y = 38.49, pch = 21, stroke = 1.2, size = 5, fill = RdBu_pal[1]) + # Colorado
  annotate("point", x = -123.48, y = 48.55, pch = 21, stroke = 1.2, size = 5, fill = RdBu_pal[3]) + # Vancouver
  annotate("point", x = 29.20, y = 66.22, pch = 21, stroke = 1.2, size = 5, fill = 'purple') + # Oulanka
  theme_bw() +
  theme(axis.title.x = element_blank(),
        axis.title.y = element_blank(),
        axis.text.y = element_blank())
