library(tidyverse)

pop_dat <- read.csv("MDG_Dmon_CSP_data/1.pop_gen.csv")

# Reorder populations
pop_dat$Location <- factor(pop_dat$Location, levels = c("Colorado", "Vancouver", "Oulanka"))

pop_dat$Met2 <- gsub("Pi", "pi", x = pop_dat$Metric)
pop_dat$Met2 <- gsub("Theta", "theta", x = pop_dat$Met2)

# plot metrics
ggplot(pop_dat, aes(x = Location, y = Value)) +
  geom_boxplot(outlier.shape = NA) +
  geom_jitter(width = .3, alpha = .7, aes(colour = Location)) +
  facet_wrap(~Met2, scales = "free_y", labeller = label_parsed) +
  scale_colour_manual(values = c(RdBu_pal[c(1,3)], "purple")) +
  theme_bw() +
  theme(legend.position = "none",
        axis.title.x = element_blank(),
        axis.text.x = element_text(face = "bold", size = 10),
        axis.title.y = element_blank(),
        strip.text = element_text(face = "bold", size = 15),
        strip.background = element_rect(fill = "grey"),
        plot.background = element_rect(colour = NA)) + 
  NULL

# Kruskal-Wallis tests followed by Wilcox tests if KW shows sig. diffs.
kruskal.test(Value ~ as.factor(Location), data = pop_dat %>% filter(Metric == 'Pi'))
pairwise.wilcox.test(pop_dat$Value[pop_dat$Metric == 'Pi'], pop_dat$Location,
                     p.adjust.method = "BH")

kruskal.test(Value ~ as.factor(Location), data = pop_dat %>% filter(Metric == 'Theta'))

kruskal.test(Value ~ as.factor(Location), data = pop_dat %>% filter(Metric == 'D'))
pairwise.wilcox.test(pop_dat$Value[pop_dat$Metric == 'D'], pop_dat$Location,
                     p.adjust.method = "BH")
