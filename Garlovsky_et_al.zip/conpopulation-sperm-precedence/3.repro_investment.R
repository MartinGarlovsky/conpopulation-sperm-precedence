library(tidyverse)

RdBu_pal <- c(RColorBrewer::brewer.pal(3, "RdBu"))

df <- read.csv("MDG_Dmon_CSP_data/3.repro_investment.csv") %>% 
  mutate(bd_wt = soma_wt + rt_wt) # calculate total body mass from soma and reproductive tract masses

str(df)
# $ population: population (Colorado or Vancouver)
# $ sex       : male or female
# $ soma_wt   : dry carcass mass - reproductive tract
# $ rt_wt     : dry reproductive tract mass
# $ bd_wt     : soma_wt + rt_wt

df$population <- factor(df$population, 
                        levels = c("Colorado", "Vancouver"))


# MALE RT INVESMENT -------------------------------------------------------
# subset males 
dfMALE <- df %>% 
  filter(sex == 'male')


# Body size differences
hist(dfMALE$bd_wt)
t.test(bd_wt ~ population, dfMALE)

# means and standard errors
dfMALE %>% 
  group_by(population) %>% 
  summarise(mn = mean(bd_wt),
            se = sd(bd_wt)/sqrt(n()),
            N = n())

# reproductive tract differences
hist(dfMALE$rt_wt)
t.test(rt_wt ~ population, dfMALE)

dfMALE %>% 
  group_by(population) %>% 
  summarise(mn = mean(rt_wt),
            se = sd(rt_wt)/sqrt(n()),
            N = n())


# Figure S8
p1 <- ggplot(dfMALE, aes(log(soma_wt), log(rt_wt), fill = population)) +
  geom_point(size = 2.5, pch = 21) +
  scale_fill_manual(values = RdBu_pal[c(1,3)]) +
  geom_point(data = dfMALE[c(26, 53, 87, 115), ], fill = 'red', pch = 21, size = 3) +
  labs(x = "Log soma mass (µg)", y = "Log reproductive tract mass (µg)") +
  theme_bw() +
  theme(legend.title = element_blank(),
        legend.text = element_text(size = 20),
        legend.position = c(0.2, 0.12),
        legend.key.height = unit(2, "line"),
        legend.background=element_blank(),
        plot.background = element_rect(colour = NA)) + 
  annotate("text", x = -1.3, y = -2, label = "(b)", size = 6)

p2 <- ggplot(dfMALE, aes(x = population, y = log(rt_wt), fill = population)) +
  geom_boxplot(outlier.size = 1.2) + 
  geom_point(data = dfMALE[c(53, 87, 115), ], colour = 'red', size = 1.2) +
  scale_fill_manual(values = RdBu_pal[c(1,3)]) +
  theme_bw() + 
  theme(legend.position = "none",
        axis.title.x = element_blank(),
        axis.text.x = element_text(size = 22, colour = NA),
        axis.text.y = element_blank(),
        axis.ticks.y = element_blank(),
        axis.title.y = element_blank(),
        plot.background = element_rect(colour = NA)) +
  geom_text(data = dfMALE[c(53, 87, 115), ] %>% 
              mutate(name = c(53, 87, 115)),
            aes(label = name), hjust = 0, vjust = 1, nudge_x = 0.05) + 
  annotate("text", x = 0.7, y = -2, label = "(c)", size = 6)

p3 <- ggplot(dfMALE, aes(x = population, y = log(soma_wt), fill = population)) + 
  geom_boxplot(outlier.size = 1.2) + 
  geom_point(data = dfMALE[26, ], colour = 'red',  size = 1.2) +
  scale_fill_manual(values = RdBu_pal[c(1,3)]) +
  coord_flip() + 
  theme_bw() + 
  theme(legend.position = "none", 
        axis.ticks.x = element_blank(),
        axis.title.x = element_blank(),
        axis.text.x = element_blank(),
        axis.title.y = element_blank(),
        axis.text.y = element_text(size = 6, colour = NA),
        plot.background = element_rect(colour = NA)) +
  geom_text(data = dfMALE[26, ] %>% 
              mutate(name = 26),
            aes(label = name), hjust = 0, vjust = 1, nudge_y = 0.05) + 
  annotate("text", x = 2.3, y = -1.3, label = "(a)", size = 6)


lay <- rbind(c(3, 3, 3, NA),
             c(1, 1, 1, 2),
             c(1, 1, 1, 2),
             c(1, 1, 1, 2))

gl <- list(p1, p2, p3)

gridExtra::grid.arrange(grobs = gl, layout_matrix = lay)



# Analysis of relative reproductive tissue investment using Analysis of covariance (ANCOVA)
hist(dfMALE$rt_wt)
m1 <- lm(log(rt_wt) ~ population * log(soma_wt), data = dfMALE)
anova(m1)
summary(m1)

drop1(m1, test = 'F') # interaction NS so drop
m2 <- update(m1, ~.-log(soma_wt):population)

drop1(m2, test = 'F')

anova(m2)
summary(m2)

# look at model diagnostics - some consistent outliers have large effect on results (e.g. high leverage)
par(mfrow = c(2, 2))
plot(m2)
par(mfrow = c(1, 1))


# look at outliers
dfMALE[c(26, 53, 87, 115), ]

ggplot(dfMALE, aes(x = log(soma_wt), y = log(rt_wt))) +
  geom_point(data = dfMALE[c(26, 53, 87, 115), ], size = 3, colour = 'red') +
  geom_point(data = dfMALE[-c(26, 53, 87, 115), ], size = 3) +
  labs(x = "Log soma mass (µg)", y = "Log reproductive tract mass (µg)") +
  theme_bw() +
  theme(legend.title = element_blank(),
        legend.text = element_text(size = 20),
        legend.position = c(0.15, 0.9),
        legend.key.height = unit(2, "line"),
        plot.background = element_rect(colour = NA)) 


# look at model exlcluding outliers
mb <- lm(log(rt_wt) ~ population * log(soma_wt), data = dfMALE[-c(26, 53, 87, 115), ])

anova(lm(log(rt_wt) ~ population * log(soma_wt), data = dfMALE[-c(26, 53, 87, 115), ]))
anova(lm(log(rt_wt) ~ log(soma_wt) * population, data = dfMALE[-c(26, 53, 87, 115), ]))

# no longer balanced - use type 2 errors
car::Anova(mb)
summary(mb)

# diagnostics look better after removing outliers
par(mfrow = c(2, 2))
plot(mb)
par(mfrow = c(1, 1))


# remove outliers
df4 <- dfMALE[-c(26, 53, 87, 115), ]

# reanalyse weigh differences after removing outliers
hist(df4$bd_wt)
t.test(bd_wt ~ population, df4)

df4 %>% 
  group_by(population) %>% 
  summarise(mn = mean(bd_wt),
            se = sd(bd_wt)/sqrt(n()),
            N = n())

t.test(rt_wt ~ population, df4)

df4 %>% 
  group_by(population) %>% 
  summarise(mn = mean(rt_wt),
            se = sd(rt_wt)/sqrt(n()),
            N = n())


mx <- lm(log(rt_wt) ~ population * log(soma_wt), data = df4)

anova(lm(log(rt_wt) ~ population * log(soma_wt), data = df4))
anova(lm(log(rt_wt) ~ log(soma_wt) * population, data = df4))

car::Anova(mx)
summary(mx)

drop1(mx, test = 'F') # interaction NS - drop
mx2 <- update(mx, ~.-population:log(soma_wt))

par(mfrow = c(2, 2))
plot(mx2)
par(mfrow = c(1, 1))


anova(lm(log(rt_wt) ~ population + log(soma_wt), data = df4))
anova(lm(log(rt_wt) ~ log(soma_wt) + population, data = df4))

car::Anova(mx2)
summary(mx2)

# Figure 4a
ggplot(df4, aes(soma_wt, rt_wt, fill = population)) +
  geom_point(size = 3, pch = 21) +
  scale_fill_manual(values = RdBu_pal[c(1,3)]) +
  labs(x = "Log soma mass (µg)", y = "Log reproductive tract mass (µg)") +
  theme_bw() +
  theme(legend.title = element_blank(),
        legend.text = element_text(size = 20),
        legend.position = c(0.15, 0.9),
        legend.key.height = unit(2, "line"),
        plot.background = element_rect(colour = NA))





# FEMALE BODY SIZE DIFFERENCES --------------------------------------------
dfFEM <- df %>% 
  filter(sex == 'female')

boxplot(dfFEM$bd_wt ~ dfFEM$population, main = "body weight")

summary(dfFEM)

hist(dfFEM$bd_wt)
t.test(bd_wt ~ population, data = dfFEM)

dfFEM %>% 
  group_by(population) %>% 
  summarise(mn = mean(bd_wt), 
            se = sd(bd_wt)/sqrt(n()),
            N = n())
